﻿using htmltopdf;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Test.Main(args);
        }
    }
}