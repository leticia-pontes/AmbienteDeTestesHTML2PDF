﻿using System;
using System.IO;
using System.Threading.Tasks;
using HtmlToPdfConverter.Services;
using QuestPDF.Infrastructure;
using QuestPDF;


public class Program
{
    public static async Task Main(string[] args)
    {
        QuestPDF.Settings.License = LicenseType.Community;
        try
        {
            var converter = new HtmlToPdfConverterService();

            string htmlFilePath = Path.Combine("..", "..", "Assets", "html", "input.html");
            string cssFilePath = Path.Combine("..", "..", "Assets", "css", "styles.css");
            string outputPdfPath = Path.Combine("..", "..", "Assets", "output.pdf");

            if (!File.Exists(htmlFilePath))
            {
                throw new FileNotFoundException($"HTML file not found at path: {htmlFilePath}");
            }
            if (!File.Exists(cssFilePath))
            {
                throw new FileNotFoundException($"CSS file not found at path: {cssFilePath}");
            }

            string cssContent = await File.ReadAllTextAsync(cssFilePath);

            await converter.ConvertAsync(htmlFilePath, cssContent, outputPdfPath);

            Console.WriteLine($"PDF successfully created at: {outputPdfPath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
    }
}
