﻿using AngleSharp;
using AngleSharp.Dom;
using HtmlToPdfConverter.Parsers;
using System.Threading.Tasks;

namespace HtmlToPdfConverter.Processors
{
    public class CssApplier
    {
        public async Task<IDocument> ApplyCssToHtmlAsync(string htmlContent, string cssContent)
        {
            var config = Configuration.Default.WithCss();
            var context = BrowsingContext.New(config);

            var document = await context.OpenAsync(req => req.Content(htmlContent));

            var cssParser = new CssParser();
            var stylesheet = cssParser.ParseCss(cssContent);

            var styleElement = document.CreateElement("style");
            styleElement.TextContent = stylesheet.ToCss();

            document.Head.AppendChild(styleElement);

            return document;
        }
    }
}
